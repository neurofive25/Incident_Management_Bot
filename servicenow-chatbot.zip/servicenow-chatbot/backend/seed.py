from pymongo import MongoClient
import datetime

client = MongoClient("mongodb+srv://neurofive25_db_user:CeRsxw3imQTA7mbe@cluster0.qfzsfzq.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0")
db = client["chatbot"]
incidents = db["incidents"]

incidents.delete_many({})

sample_data = [
    {"category": "VPN outage", "created_at": datetime.datetime(2025, 7, 10)},
    {"category": "VPN outage", "created_at": datetime.datetime(2025, 8, 15)},
    {"category": "Email failure", "created_at": datetime.datetime(2025, 9, 20)},
    {"category": "Server crash", "created_at": datetime.datetime(2025, 9, 25)},
]

incidents.insert_many(sample_data)
print("✅ Sample data inserted!")
