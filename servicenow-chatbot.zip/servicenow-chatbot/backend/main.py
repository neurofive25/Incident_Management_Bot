from fastapi import FastAPI
from pydantic import BaseModel
from pymongo import MongoClient
import requests
import os

MONGO_URI = os.getenv("MONGO_URI", "mongodb+srv://neurofive25_db_user:CeRsxw3imQTA7mbe@cluster0.qfzsfzq.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0")
OLLAMA_URL = os.getenv("OLLAMA_URL", "http://localhost:8000/chat")
MODEL = os.getenv("OLLAMA_MODEL", "deepseek-r1")

app = FastAPI()
client = MongoClient(MONGO_URI)
db = client["chatbot"]
incidents = db["incidents"]

class ChatRequest(BaseModel):
    message: str

class QueryRequest(BaseModel):
    mongo_query: dict

def ask_deepseek(prompt: str) -> str:
    payload = {
        "model": MODEL,
        "messages": [{"role": "user", "content": prompt}]
    }
    try:
        resp = requests.post(OLLAMA_URL, json=payload)
        data = resp.json()
        return data.get("message", {}).get("content", "No response")
    except Exception as e:
        return f"Error calling Ollama: {str(e)}"

@app.post("/chat")
def chat(req: ChatRequest):
    mongo_query = ask_deepseek(f"Generate a MongoDB query for: {req.message}")
    try:
        query_dict = {"category": {"$regex": "VPN", "$options": "i"}}
        result_count = incidents.count_documents(query_dict)
    except Exception as e:
        return {"error": str(e), "generated_query": mongo_query}

    summary = ask_deepseek(
        f"The query returned {result_count}. Summarize this result in plain English."
    )
    return {
        "user_message": req.message,
        "generated_query": mongo_query,
        "result": result_count,
        "summary": summary,
    }

@app.post("/query")
def run_query(req: QueryRequest):
    try:
        cursor = incidents.find(req.mongo_query)
        results = list(cursor)
        return {"results": results}
    except Exception as e:
        return {"error": str(e)}
