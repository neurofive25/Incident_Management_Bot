import React from "react";

function ChatBox({ chat }) {
  return (
    <div style={{ border: "1px solid #ccc", padding: 10, height: 300, overflowY: "scroll" }}>
      {chat.map((msg, i) => (
        <p key={i}><b>{msg.role}:</b> {msg.content}</p>
      ))}
    </div>
  );
}

export default ChatBox;
