import React, { useState } from "react";
import axios from "axios";
import ChatBox from "./components/ChatBox";

function App() {
  const [chat, setChat] = useState([]);
  const [message, setMessage] = useState("");

  const sendMessage = async () => {
    if (!message) return;
    setChat([...chat, { role: "user", content: message }]);

    try {
      const res = await axios.post("http://localhost:8000/chat", { message });
      setChat(prev => [...prev, { role: "bot", content: res.data.summary }]);
    } catch (err) {
      console.error(err);
    }
    setMessage("");
  };

  return (
    <div style={{ padding: 20 }}>
      <h2>ServiceNow Incident Chatbot</h2>
      <ChatBox chat={chat} />
      <input
        style={{ width: "80%", marginTop: 10 }}
        value={message}
        onChange={(e) => setMessage(e.target.value)}
        onKeyPress={(e) => e.key === "Enter" && sendMessage()}
      />
      <button onClick={sendMessage} style={{ marginLeft: 10 }}>Send</button>
    </div>
  );
}

export default App;
