# ServiceNow Chatbot (Hackathon Demo)

## 🚀 Stack
- Frontend: React
- Backend: FastAPI (Python)
- DB: MongoDB
- Model: DeepSeek (via Ollama)

---

## 🔧 Setup

### 1. Start MongoDB
Install and run MongoDB locally:

    mongod --dbpath <your_db_path>

### 2. Seed Data
    cd backend
    pip install -r requirements.txt
    python seed.py

### 3. Run Backend
    uvicorn main:app --reload --port 8000

### 4. Run Frontend
    cd frontend
    npm install
    npm start

Then open 👉 http://localhost:3000

### 5. Run Model (Ollama)
Install [Ollama](https://ollama.com/) and pull DeepSeek:

    ollama pull deepseek-r1

---
✅ Example query:
*User*: "How many VPN outages in the last 3 months?"  
*Bot*: "There were 2 VPN outage incidents reported in the last 3 months."
